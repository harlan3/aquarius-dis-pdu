package uk.ac.leeds.ccg.geotools;

import java.awt.*;

public class ShaderChangedEvent extends java.util.EventObject
{
	public ShaderChangedEvent(Object source){
        super(source);

    }
}