package uk.ac.leeds.ccg.geotools;
import java.awt.*;

public interface Marker
{
    public void paintScaled(GeoGraphics g,GeoPoint p,int size, Color color, boolean isSelected);
    public void paintHighlight(Graphics g,GeoPoint p,int size,Scaler scale,ShadeStyle style);
}