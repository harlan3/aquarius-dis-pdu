/*
 * DataSource.java
 *
 * Created on October 25, 2001, 12:42 PM
 */

package uk.ac.leeds.ccg.geotools;

/**
 *
 * @author  jamesm
 * @version 
 */
public interface DataSource {

}

