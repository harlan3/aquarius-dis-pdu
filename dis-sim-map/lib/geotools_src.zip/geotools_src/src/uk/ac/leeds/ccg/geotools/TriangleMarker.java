package uk.ac.leeds.ccg.geotools;
import java.awt.*;

public class TriangleMarker implements uk.ac.leeds.ccg.geotools.Marker
{
    public void paintScaled(GeoGraphics gg,GeoPoint p, int size, Color color, boolean isSelected) {

        // Draw selection square
    	{
    		if (isSelected) {
		        Scaler s = gg.getScale();
		        ShadeStyle st = gg.getStyle();
		        int mysize = size + 2;
		        int mid[] = s.toGraphics(p);
		        Graphics g = gg.getGraphics();
		        int x[] = {mid[0]-mysize,mid[0]-mysize,mid[0]+mysize,mid[0]+mysize};
		        int y[] = {mid[1]-mysize,mid[1]+mysize,mid[1]+mysize,mid[1]-mysize};
		        //g.setColor(st.getFillColor());
		        g.setColor(Color.YELLOW);
		        g.fillPolygon(x,y,4);
		        g.drawPolygon(x,y,4);
    		}
    	}
    	
    	// Draw triangle
    	{
	        Scaler s = gg.getScale();
	        ShadeStyle st = gg.getStyle();
	        int mid[] = s.toGraphics(p);
	        Graphics g = gg.getGraphics();
	        int x[] = {mid[0]-size,mid[0],mid[0]+size};
	        int y[] = {mid[1]+size,mid[1]-size,mid[1]+size};
	        g.setColor(color);
	        g.fillPolygon(x,y,3);
	        g.setColor(Color.BLACK);
	        g.drawPolygon(x,y,3);
    	}
    }

	@Override
	public void paintHighlight(Graphics g, GeoPoint p, int size, Scaler scale, ShadeStyle style) {
		// TODO Auto-generated method stub
		
	} 
}