package uk.ac.leeds.ccg.shapefile;

/**
 * Thrown when an error relating to the shapefile
 * occures
 */
public class ShapefileException extends Exception{
    public ShapefileException(String s){
        super(s);
    }
}




