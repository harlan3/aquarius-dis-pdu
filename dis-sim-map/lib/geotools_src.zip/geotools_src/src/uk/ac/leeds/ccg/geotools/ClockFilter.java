/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;

/**
 * A special filter for dealing with time of day data (or any data that falls within a cyclical period).
 * A start time and span can be specified.  Any values that lie after start but before start+span are considered visible.
 * The interesting property is that if start+span goes off the end of the span it is wrapped back through the start of the cycle.
 * For example, on a 24 hour clock, a filter of start=20 and span=6 would include all values from 20h->24h and then from 0h->2h.
 *
 * $Log: ClockFilter.java,v $
 * Revision 1.2  2002/02/23 23:02:45  loxnard
 * Fixed JavaDoc comments.
 *
 *
 * @author James Macgill
 * @version $Revision: 1.2 $ $Date: 2002/02/23 23:02:45 $
 * @since before 0.8.0
 */
public class ClockFilter extends uk.ac.leeds.ccg.geotools.SimpleFilter implements Cloneable{
    
    boolean isSimple = false;
    
    /**
     * A data set with associated IDs to use in this filter.
     */    
    public uk.ac.leeds.ccg.geotools.GeoData data;
    
    /** Utility field used by bound properties. */
    private java.beans.PropertyChangeSupport propertyChangeSupport = new java.beans.PropertyChangeSupport(this);
    
    /** Holds value of property cycleStart. */
    private double cycleStart;
    
    /** Holds value of property cycleLength. */
    private double cycleLength;
    
    /** Holds value of property startPoint. */
    private double startPoint;
    
    /** Holds value of property span. */
    private double span;
    
    /**
     * Default constructor.  Care must be used to ensure that ClockFilter is properly configured before it is first used.
     */    
    public ClockFilter(){}
    
    /**
     * Creates new ClockFilter and initializes settings.
     * @param d The data set to use with this filter.  Nb. Min. and max. values are determined from this data set so if the clock cycle is longer you should ensure this gets set separately.
     */
    public ClockFilter(GeoData d) {
        data = d;
        setCycle(d.getMin(),d.getMax()-d.getMin()+1);
        setActiveSlice(cycleStart,cycleLength);
       
    }

    /**
     * Header string used when outputting filter settings to file.
     * @return The Header string.
     */    
    public String getHeader(){
        return "CF"+data.getName()+"startPoint,CF"+data.getName()+"span";
    }
    
    /**
     * Data string used when outputting filter settings to file.
     * @return All of the parameters of this filter as a comma-separated string.
     */    
    public String getAsRow(){
        return ""+startPoint+","+span;
    }
    
    /**
     * Sets the start and end points of the clock cycle (e.g. a 24 hour clock would be start=0, length=24).
     * @param start The smallest value in the clock cycle.
     * @param length The duration of the clock cycle.
     */    
    public void setCycle(double start,double length){
        setCycleStart(start);
        setCycleLength(length);
    }
    
    /**
     * The portion of the clock cycle for which values will be considered visible.
     * @param start The start of the active slice.
     * @param span The duration of the active slice (nb. this will wrap round to the beginning of the clock cycle if needed).
     */    
    public void setActiveSlice(double start,double span){
        setStartPoint(start);
        setSpan(span);
    }
    
    
    private void updateTestType(){
        if((startPoint+span)<(cycleStart+cycleLength)){
            //does not cross cycle limit
            isSimple=true;
        }
        else{
            isSimple=false;
        }
    }
        
    /**
     * Checks the given ID against the filter.
     * @param id ID to check against the filter.
     * @return Returns true if features with this ID should be included in any displays.
     */
    public boolean isVisible(int id) {
        double value = data.getValue(id);
        return isVisible(value);
    }
    
    /**
     * Check the given ID against the filter.
     * @param value ID to check against the filter.
     * @return Returns true if features with this ID should be included in any displays.
     */    
    public boolean isVisible(double value){
        if(isSimple){
            return value>=startPoint && value<startPoint+span;
        }
        else{
            return value>=startPoint || value<  ((startPoint+span)%(cycleStart+cycleLength)+cycleStart);
        }
    }
        
    
    /**
     * Adds a PropertyChangeListener to the listener list.
     * @param l The listener to add.
     */
    public void addPropertyChangeListener(java.beans.PropertyChangeListener l) {
        propertyChangeSupport.addPropertyChangeListener(l);
    }
    
    /** Removes a PropertyChangeListener from the listener list.
     * @param l The listener to remove.
     */
    public void removePropertyChangeListener(java.beans.PropertyChangeListener l) {
        propertyChangeSupport.removePropertyChangeListener(l);
    }
    
    /** Getter for property data.
     * @return Value of property data.
     */
    public uk.ac.leeds.ccg.geotools.GeoData getData() {
        return data;
    }
    
    /** Setter for property data.
     * @param data New value of property data.
     */
    public void setData(uk.ac.leeds.ccg.geotools.GeoData data) {
        uk.ac.leeds.ccg.geotools.GeoData oldData = this.data;
        this.data = data;
        setCycle(data.getMin(),data.getMax()-data.getMin()+1);
        setActiveSlice(cycleStart,cycleLength);
        propertyChangeSupport.firePropertyChange("data", oldData, data);
    }
    
    /** Getter for property cycleStart.
     * @return Value of property cycleStart.
     */
    public double getCycleStart() {
        return cycleStart;
    }
    
    /** Setter for property cycleStart.
     * @param cycleStart New value of property cycleStart.
     */
    public void setCycleStart(double cycleStart) {
        double oldCycleStart = this.cycleStart;
        this.cycleStart = cycleStart;
        updateTestType();
        super.notifyFilterChangedListeners(FilterChangedEvent.DATA);
        propertyChangeSupport.firePropertyChange("cycleStart", new Double(oldCycleStart), new Double(cycleStart));
    }
    
    /** Getter for property cycleLength.
     * @return Value of property cycleLength.
     */
    public double getCycleLength() {
        return cycleLength;
    }
    
    /** Setter for property cycleLength.
     * @param cycleLength New value of property cycleLength.
     */
    public void setCycleLength(double cycleLength) {
        double oldCycleLength = this.cycleLength;
        this.cycleLength = cycleLength;
        updateTestType();
        super.notifyFilterChangedListeners(FilterChangedEvent.DATA);
        propertyChangeSupport.firePropertyChange("cycleLength", new Double(oldCycleLength), new Double(cycleLength));
    }
    
    /** Getter for property startPoint.
     * @return Value of property startPoint.
     */
    public double getStartPoint() {
        return startPoint;
    }
    
    /** Setter for property startPoint.
     * @param startPoint New value of property startPoint.
     */
    public void setStartPoint(double startPoint) {
        double oldStartPoint = this.startPoint;
        if(startPoint<cycleStart)startPoint=cycleStart;
        this.startPoint = startPoint;
        updateTestType();
        super.notifyFilterChangedListeners(FilterChangedEvent.DATA);
        propertyChangeSupport.firePropertyChange("startPoint", new Double(oldStartPoint), new Double(startPoint));
    }
    
    /** Getter for property span.
     * @return Value of property span.
     */
    public double getSpan() {
        return span;
    }
    
    /** Setter for property span.
     * @param span New value of property span.
     */
    public void setSpan(double span) {
        double oldSpan = this.span;
        if(span>cycleLength)span=cycleLength;
        this.span = span;
        updateTestType();
        super.notifyFilterChangedListeners(FilterChangedEvent.DATA);
        propertyChangeSupport.firePropertyChange("span", new Double(oldSpan), new Double(span));
    }
    
    /**
     * Converts all of the properties into a String.
     * @return All of the properties as a String.
     */    
    public String toString(){
        return "Clock Filter "+data.getName()+"From "+startPoint+" for "+span+ " to "+((startPoint+span)%(cycleStart+cycleLength)+cycleStart);
    }
    
    /**
     * Constructs a new ClockFilter with the same settings as this one.
     * @return A new ClockFilter.
     */    
    public Object clone(){
        ClockFilter clone = new ClockFilter(data);
        clone.setCycle(getCycleStart(),getCycleLength());
        clone.setActiveSlice(getStartPoint(),getSpan());
        return clone;
    }
    
    
    
}
