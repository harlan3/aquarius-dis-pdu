package uk.ac.leeds.ccg.geotools;

import java.util.*;

public class ViewerEvent extends java.util.EventObject
{
	public ViewerEvent(Object source)
	{
		super(source);
	}
}