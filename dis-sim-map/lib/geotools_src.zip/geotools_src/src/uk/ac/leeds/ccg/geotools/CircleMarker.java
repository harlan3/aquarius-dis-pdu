/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;
import java.awt.*;

/**
 *
 * Marker for use in marker layers.  Displays each point as a small circle.
 *
 * $Log: CircleMarker.java,v $
 * Revision 1.3  2002/02/23 22:37:09  loxnard
 * Fixed JavaDoc comments.
 *
 *
 * @author James Macgill
 * @version $Revision: 1.3 $ $Date: 2002/02/23 22:37:09 $
 * @since before 0.8.0
 */
public class CircleMarker implements uk.ac.leeds.ccg.geotools.Marker
{
    /**
     * Paints a single marker to the screen.
     * The calling and filling in of this method is handled by the markerLayer to which
     * this marker has been added.<p>
     * The GeoGraphics object should provide you with everything
     * needed to plot a feature onto the screen.<br>
     * Inside gg you can use or not use the facilities provided as you see fit.<p>
     * gg.getGraphics() A Graphics object to which you should direct all of your output.
     * gg.getScale() A Scaler which you can use to convert real world(tm) co-ordinates
     * into on-screen co-ordinates for use with the Graphics g object.
     * gg.getShade() A Shader.  If you want to colour your features based on a value (perhaps from the data parameter) then
     * use shade.getColor(double value); to obtain the colours.
     * gg.getGeoData() A GeoData object.  Use this if your features have IDs then you can obtain a corresponding value
     * from data.
     * gg.getStyle() A style with hints on how to display the features.
     * @param gg A GeoGraphics object which provides everything needed to plot a feature onto the screen.
     * @param p The geographic coordinates of the marker to be displayed.
     * @param size The size, in pixels, for the marker.
     */    
    public void paintScaled(GeoGraphics gg,GeoPoint p,int size, Color color, boolean isSelected)
    {
        Scaler s = gg.getScale();
        ShadeStyle st = gg.getStyle();
        int mid[] = s.toGraphics(p);
        Graphics g = gg.getGraphics();
        
        if(st.isFilled()){
          g.setColor(st.getFillColor());
          g.fillOval(mid[0]-size,mid[1]-size,size*2,size*2);
        }
        if(st.isOutlined()){
          g.setColor(new Color(42, 48, 53));
          g.drawOval(mid[0]-size,mid[1]-size,size*2,size*2);
        }
    }
    
    /**
     * Displays a single marker in a highlighted style.
     * @param g A graphics object to paint to.
     * @param p The geographic coordinates of the marker to be displayed.
     * @param size The size, in pixels, for the marker.
     * @param scale A scaler for translating between geographic and screen coordinates.
     * @param style A style to be applied to the marker's appearance.
     */    
    public void paintHighlight(Graphics g,GeoPoint p,int size,Scaler scale,ShadeStyle style) {
     
        Scaler s = scale;
        ShadeStyle st = style;
        int mid[] = s.toGraphics(p);
        size = st.getLineWidth();
       
        if(st.isFilled()){
          g.setColor(st.getFillColor());
          g.fillOval(mid[0]-size,mid[1]-size,size*2,size*2);
        }
        if(st.isOutlined()){
          g.setColor(new Color(42, 48, 53));
          g.drawOval(mid[0]-size,mid[1]-size,size*2,size*2);
        }
        
    }
    
}


