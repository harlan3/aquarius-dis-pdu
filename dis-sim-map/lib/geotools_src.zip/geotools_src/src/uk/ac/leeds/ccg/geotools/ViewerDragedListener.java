package uk.ac.leeds.ccg.geotools;

public interface ViewerDragedListener extends java.util.EventListener
{
    public void viewerDraged(ViewerDragedEvent e);
}