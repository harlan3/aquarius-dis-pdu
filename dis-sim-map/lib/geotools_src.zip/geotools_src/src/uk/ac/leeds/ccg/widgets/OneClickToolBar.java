package uk.ac.leeds.ccg.widgets;

import java.awt.*;
import java.awt.event.*;
import java.util.*;
import uk.ac.leeds.ccg.geotools.*;

public class OneClickToolBar extends ToolBar{
	public OneClickToolBar(Viewer ve){
		this(ve,false);
	}
	public OneClickToolBar(Viewer ve, boolean sel){
		this(ve,sel,true);
	}
	public OneClickToolBar(Viewer ve,boolean sel, boolean check){
    viewers.addElement(ve);
    ve.getScale().addScaleChangedListener(this);
    views=0;
    tools[0]= new Vector();
    checkbox = check;
    reset = new Button("Reset");
    add(reset);
    controls.addElement(reset);
    reset.addActionListener(this);
    addTool(new OneClickZoomInTool());
    addTool(new OneClickZoomOutTool());
    addTool(new CenterOnPointTool());
    if(sel)addTool(new SelectTool());
	}
}
		
