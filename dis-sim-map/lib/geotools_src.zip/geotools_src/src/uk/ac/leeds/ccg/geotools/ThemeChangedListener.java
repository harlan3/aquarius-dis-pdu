package uk.ac.leeds.ccg.geotools;

public interface ThemeChangedListener extends java.util.EventListener {
    void themeChanged(ThemeChangedEvent tce);

}
