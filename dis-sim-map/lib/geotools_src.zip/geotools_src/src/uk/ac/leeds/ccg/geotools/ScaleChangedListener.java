package uk.ac.leeds.ccg.geotools;

public interface ScaleChangedListener extends java.util.EventListener
{
    void scaleChanged(ScaleChangedEvent sce);
}