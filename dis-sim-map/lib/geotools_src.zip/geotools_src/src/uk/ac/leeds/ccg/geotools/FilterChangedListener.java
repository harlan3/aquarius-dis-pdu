package uk.ac.leeds.ccg.geotools;

public interface FilterChangedListener extends java.util.EventListener {
    void filterChanged(FilterChangedEvent ce);

}
