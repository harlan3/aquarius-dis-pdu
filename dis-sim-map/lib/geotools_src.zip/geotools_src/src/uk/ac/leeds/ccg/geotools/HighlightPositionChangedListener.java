package uk.ac.leeds.ccg.geotools;

public interface HighlightPositionChangedListener extends java.util.EventListener {
    void highlightPositionChanged(HighlightPositionChangedEvent hpce);

}