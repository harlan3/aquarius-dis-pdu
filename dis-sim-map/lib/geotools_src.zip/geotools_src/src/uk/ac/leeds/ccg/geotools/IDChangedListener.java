package uk.ac.leeds.ccg.geotools;

public interface IDChangedListener extends java.util.EventListener {
    void idChanged(IDChangedEvent ice);

}