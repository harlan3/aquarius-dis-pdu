package uk.ac.leeds.ccg.geotools.projections;


public abstract class ConicEquidistant implements Projection
{
}