/*
 * DotFill.java
 *
 * Created on 26 October 2001, 20:16
 */

package uk.ac.leeds.ccg.geotools.misc;
import java.awt.*;
/**
 *
 * @author  Ian Turton
 * @version
 */
public class DotFill {
    
    /** Creates new DotFill */
    public DotFill() {
    }
    
    public static void fillPolygon(Graphics g,Polygon poly,int diameter,int distance){
        int x[] = poly.xpoints;
        int y[] = poly.ypoints;
        int n = poly.npoints;
        
        
        double p;//cos/sine of angle offset of tmp polygon
				int k;
        
        double HI =-Double.MAX_VALUE;
        double LO =Double.MAX_VALUE;
        
        //rotate the polygon so that hatch lines are horezontal
        for(int i=0;i<n;i++){
            LO = Math.min(y[i],LO);
            HI = Math.max(y[i],HI);
        }
				p=((y[0]-LO)%distance)+LO;

        if(p>LO) p=p-distance;
        k = (int)((HI-p)/distance);
        if(k<=0 && distance<=0){
						System.err.println("No hatching possible");
            return;
        }
				double[] ord = new double[k];
				//k is the number of hatches to draw
				for(int i=0;i<k;i++){
					int m=0;
					p+=distance;
					for(int l=0;l<n;l++){
					int j = (l+1)%n; // index of "next" point
					if(y[l]<=p&&y[j]<=p) continue;
					if(y[l]>p&&y[j]>p) continue;
					ord[m]=x[l]+(x[j]-x[l])*(p-y[l])/(y[j]-y[l]);
					m++;
				}
				if(m%2!=0){System.err.println("Rounding error in DotFill hatch");}
				if(m==0)continue;
				//sort ord
				for(int j=1;j<m;j++){
					int ns = m+1-j;
					for(int l=1;l<ns;l++){
						if(ord[l-1]>ord[l]){
							double q = ord[l];
							ord[l]=ord[l-1];
							ord[l-1]=q;
						}
					}
				}
				int ns=0;
				int xh[] = new int[n];
				for(int j=1;j<m;j=j+2){
					for(int jj=0;jj<2;jj++){
						xh[jj]=(int)(ord[ns]);
						ns++;
					}
					for(int tx=(int)(xh[0]+(distance/2.0));
						tx<xh[1]-distance/2+diameter/2;
						tx+=distance)
						g.fillOval((int)(tx-diameter/2),(int)(p-diameter/2),
							diameter,diameter);
				}
			}            
		}
}
