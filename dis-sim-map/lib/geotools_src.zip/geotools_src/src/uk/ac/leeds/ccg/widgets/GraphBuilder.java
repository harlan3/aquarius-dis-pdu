package uk.ac.leeds.ccg.widgets;

public class GraphBuilder
{
}