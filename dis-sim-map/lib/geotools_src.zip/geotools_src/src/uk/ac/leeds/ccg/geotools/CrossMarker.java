/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;
import java.awt.*;

/**
 * Marker for use in marker layers.  Displays each point as a small cross.
 *
 * $Log: CrossMarker.java,v $
 * Revision 1.2  2002/03/09 12:52:54  loxnard
 * Fixed JavaDoc comments.
 *
 *
 * @author Ian Turton
 * @version $Revision: 1.2 $ $Date: 2002/03/09 12:52:54 $
 * @since before 0.8.0
 */
public class CrossMarker implements uk.ac.leeds.ccg.geotools.Marker
{
    /**
     * Paints a single marker to the screen.
     * The calling and filling in of this method is handled by the markerLayer to which
     * this marker has been added.<p>
     * The GeoGraphics object should provide you with everything
     * needed to plot a feature onto the screen.<br>
     * Inside gg you can use or not use the facilities provided as you see fit.<p>
     * gg.getGraphics() A Graphics object to which you should direct all of your output.
     * gg.getScale() A Scaler which you can use to convert real world(tm) co-ordinates
     * into on-screen co-ordinates for use with the Graphics g object.
     * gg.getShade() A Shader.  If you want to colour your features based on a value (perhaps from the data parameter) then
     * use shade.getColor(double value); to obtain the colours.
     * gg.getGeoData() A GeoData object.  Use this if your features have IDs then you can obtain a corresponding value
     * from data.
     * gg.getStyle() A style with hints on how to display the features.
     * @param gg A GeoGraphics object which provides everything needed to plot a feature onto the screen.
     * @param p The geographic coordinates of the marker to be displayed.
     * @param size The size, in pixels, for the marker.
     */    
    public void paintScaled(GeoGraphics gg, GeoPoint p,int size, Color color, boolean isSelected)
    {
        Scaler s = gg.getScale();
        ShadeStyle st = gg.getStyle();
        int mid[] = s.toGraphics(p);
				int s4 = (int)Math.ceil(size/4.0);
				int x1 = mid[0];
				int y1 = mid[1];
        Graphics g = gg.getGraphics();
        int x[] = {x1-size,x1-s4,x1-s4,x1+s4,x1+s4,x1+size,x1+size,
				x1+s4,x1+s4,x1-s4,x1-s4,x1-size};
        int y[] = {y1+s4,y1+s4,y1+size,y1+size,y1+s4,y1+s4,y1-s4,y1-s4,y1-size,
				y1-size,y1-s4,y1-s4};
        g.setColor(st.getFillColor());
        g.fillPolygon(x,y,12);
        g.setColor(new Color(42, 48, 53));
        g.drawPolygon(x,y,12);
    }
    
    /**
     * Displays a single marker in a highlighted style.
     * @param g A graphics object to paint to.
     * @param p The geographic coordinates of the marker to be displayed.
     * @param size The size, in pixels, for the marker.
     * @param scale A scaler for translating between geographic and screen coordinates.
     * @param style A style to be applied to the marker's appearance.
     */    
    public void paintHighlight(Graphics g,GeoPoint p,int size,Scaler scale,ShadeStyle style) {
     
        int mid[] = scale.toGraphics(p);
				int s4 = (int)Math.ceil(size/4.0);
				int x1 = mid[0];
				int y1 = mid[1];
        
        size+=2;
        int x[] = {x1-size,x1-s4,x1-s4,x1+s4,x1+s4,x1+size,x1+size,
				x1+s4,x1+s4,x1-s4,x1-s4,x1-size};
        int y[] = {y1+s4,y1+s4,y1+size,y1+size,y1+s4,y1+s4,y1-s4,y1-s4,y1-size,
				y1-size,y1-s4,y1-s4};
        g.setColor(style.getFillColor());
        g.fillPolygon(x,y,12);
        g.setColor(new Color(42, 48, 53));
        g.drawPolygon(x,y,12);
        
    }
    
}
