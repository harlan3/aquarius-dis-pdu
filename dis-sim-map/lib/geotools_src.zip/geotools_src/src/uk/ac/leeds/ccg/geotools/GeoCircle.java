/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */


package uk.ac.leeds.ccg.geotools;

import java.lang.*;
import java.awt.*;
import java.util.*;

/**
* This class is intended for storing circles such as those that make up cartograms.
*
* $Log: GeoCircle.java,v $
* Revision 1.4  2002/01/19 18:07:27  loxnard
* Fixed JavaDoc comments.
*
*
* @author James Macgill
* @version $Revision: 1.4 $ $Date: 2002/01/19 18:07:27 $
* @since 0.6.3
*/
public class GeoCircle extends GeoShape {
	

	/**
	 * Circle centroid coordinates.
	 */
	private double xcent,ycent;

	/**
	 * The circle's radius.
	 */
	private double radius;

	/**
	 * Minimum bounding box for polygon.
	 */
	//private GeoRectangle bBox = new GeoRectangle(); //*The bounding box

	/**
         * Create an empty circle.
         */
	public GeoCircle(){setBounds(new GeoRectangle());} //Empty
        /**
         * Construct a circle with full details.
         * @param id Circle ID.
         * @param cent X and Y coordinates of centroid.
         * @param r Radius of circle.
         */        
	public GeoCircle(int id,GeoPoint cent,double r) {
		this(id,cent.getX(),cent.getY(),r);
	}

        /**
         * Construct a circle with full details.
         *
         * @param id Circle ID.
         * @param xcent X coordinate of centroid.
         * @param ycent Y coordinate of centroid.
         * @param r Radius of circle.
         */
	public GeoCircle(int id,double xcent,double ycent,double r) {
		this.id = id;
		this.xcent = xcent;
		this.ycent = ycent;
		radius = r;
		//Update the bounding box
		setBounds(new GeoRectangle());
        extendBounds(xcent-radius,ycent-radius);
        extendBounds(xcent+radius,ycent+radius);
	    //bBox = new GeoRectangle(xcent-radius,ycent+radius,(double)((int)(2d*radius)+1),(double)((int)(2d*radius)+1));
	    //bBox = new GeoRectangle(xcent-radius,ycent-radius,2*radius,2*radius);
	    //bBox = new GeoRectangle(xcent,ycent,2*radius,2*radius);
        
	}

	
        /**
         * Sets the centre of the circle.
         * @param p X and Y coordinates of centroid.
         */        
	public void setCentre(GeoPoint p){
		setCentre(p.getX(),p.getY());
	}
        /**
         * Sets the centre of the circle.
         * @param x X coordinate of centroid.
         * @param y Y coordinate of centroid.
         */        
	public void setCentre(double x, double y){
		xcent=x;
		ycent=y;
		setBounds(new GeoRectangle());
		extendBounds(xcent-radius,ycent-radius);
		extendBounds(xcent+radius,ycent+radius);
	}
        /**
         * Sets radius of circle.
         * @param r Radius of circle.
         */        
	public void setRadius(double r){
		radius=r;
		setBounds(new GeoRectangle());
		extendBounds(xcent-radius,ycent-radius);
		extendBounds(xcent+radius,ycent+radius);
	}
	
        /**
         * Calculates and returns the area of this circle.
         * @return The area of the circle.
         */
        public double getArea(){
            return Math.PI*Math.pow(getRadius(),2);
        }
        /**
         * Gets the centroid of this circle.
         * @return The centroid of this circle.
         */        
    public GeoPoint getCentroid(){
        return new GeoPoint(xcent,ycent);
    }

    /**
     * Gets the point making up the centroid of this circle.
     * @return Vector containing centroid point.
     */    
    public Vector getPoints(){
        Vector v = new Vector();
        v.addElement(new GeoPoint(xcent,ycent));
        return v;
    }

	/**
         * Returns the circle ID.
         * @return Circle ID.
         */
	 public int getID(){
	    return id;
	 }
	 
	 /**
          * Returns circle radius.
          * @return Radius of this circle.
          */
	  public double getRadius(){return radius;}
	  
	 /**
          * Returns centre of this circle.
          * @return X and Y coordinates of centre of circle.
          * @deprecated use uk.ac.leeds.ccg.geotools.GeoCircle#getCentroid instead.
          */
	  public GeoPoint getCentrid(){
	    return new GeoPoint(xcent,ycent);
	  }
	  
          /**
           * Gets the X coordinate of the circle centre.
           * @return X coordinate of circle centre.
           */          
	  public double getX(){
	    return xcent;
	  }
          /**
           * Gets Y coordinate of circle centre.
           * @return Y coordinate of circle centre.
           */          
	  public double getY(){return ycent;}
	  


	  /**
           * Checks whether the specified point is inside the circle.
           * @param p The point to test.
           * @return True if point is inside circle.
           */
	   public boolean contains(GeoPoint p){
	    if (!getBounds().contains(p)){
	        return false;
	    }
	    double dist = Math.sqrt(Math.pow(p.x-xcent,2)+Math.pow(p.y-ycent,2));
	    if(dist<radius){
	        return true;
	    }
	    return false;
	   
	   }

       GeoPoint testContains = new GeoPoint(0,0); 
       /**
        * Checks to see if point is inside circle.
        * @param x X coordinate of point.
        * @param y Y coordinate of point.
        * @return True if point is inside circle.
        */       
	   public boolean contains(double x,double y){
	    testContains.setLocation(x,y);
	    return contains(testContains);
	   }
	   
           /**
            * Checks to see if this circle is wholly contained by another circle.
            * @param c Circle to test.
            * @return True if circle is contained by c.
            */           
	   public boolean isContainedBy(GeoCircle c){
	    double dist;
	    GeoPoint p1 = c.getCentroid();
	    GeoPoint p2 = getCentroid();
	    dist = p1.getDistance(p2);
	    return(dist+getRadius()<=c.getRadius());
	   }
	   
           /**
            * Checks to see whether this circle is contained by the given shape.
            * @param container Shape to test.
            * @return True if this circle is contained by container.
            */           
	   public boolean isContainedBy(GeoShape container){
	    if(container instanceof GeoCircle){return isContainedBy ((GeoCircle)container);}
	    //if bounding boxes do not interact at all return false
	    if(!getBounds().intersects(container.getBounds())) return false;
	    
	    //work in reverse for circles
	    //if any of the containers points are inside, return false
	    
	    Enumeration e = container.getPoints().elements();
        boolean inside = false;
        //test each point individualy, abort if any point is inside
        while(e.hasMoreElements() && !inside){
            GeoPoint p = (GeoPoint)e.nextElement();
            inside = contains(p);
        }
        return !inside;
	   }
	   
	   /**
            * This GeoCircle described in a string.
            * @return String.  The description in the form 'GeoCircle [id i] x,y,r'.
            */
	    public String toString(){
	        return ("GeoCircle [id "+id+"] "+xcent+","+ycent+","+radius);
	    }
	   
	  
}



