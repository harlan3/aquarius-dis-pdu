package uk.ac.leeds.ccg.geotools;

public interface ViewerUpdatedListener extends java.util.EventListener
{
    public void viewerUpdated(ViewerUpdatedEvent e);
}