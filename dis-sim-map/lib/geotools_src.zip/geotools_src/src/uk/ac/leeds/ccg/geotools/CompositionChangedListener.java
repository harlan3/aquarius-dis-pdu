/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;

/**
 * Implemented by classes which need to know when the number or order of things within a Viewer has changed.
 *
 * $Log: CompositionChangedListener.java,v $
 * Revision 1.2  2002/03/09 12:42:29  loxnard
 * Fixed JavaDoc comments.
 *
 *
 * @author  James Macgill
 * @version $Revision: 1.2 $ $Date: 2002/03/09 12:42:29 $
 * @since before 0.8.0 
 */
public interface CompositionChangedListener extends java.util.EventListener {
    void compositionChanged(CompositionChangedEvent cce);
  
}