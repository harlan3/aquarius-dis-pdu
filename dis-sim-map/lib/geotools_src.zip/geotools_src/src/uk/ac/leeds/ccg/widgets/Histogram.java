/*
 * Histogram.java
 *
 * Created on March 6, 2001, 2:31 PM
 */

package uk.ac.leeds.ccg.widgets;

/**
 *
 * @author  jamesm
 * @version 
 */
public class Histogram extends java.lang.Object {

    /** Creates new Histogram */
    public Histogram() {
    }

}
