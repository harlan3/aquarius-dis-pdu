/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;

/**
 * Holds a list of features contiguous with the specified feature.
 *
 * $Log: ContiguityList.java,v $
 * Revision 1.2  2002/03/09 12:48:16  loxnard
 * Fixed JavaDoc comments.
 *
 *
 * @author James Macgill
 * @version $Revision: 1.2 $ $Date: 2002/03/09 12:48:16 $
 * @since before 0.8.0
 */
public class ContiguityList
{
    int id;
    int[] list;
    /**
     * Constructs a new ContiguityList.
     * @param id ID of feature whose ContiguityList is to be stored.
     * @param list IDs of features contiguous to id.
     */    
    public ContiguityList(int id,int[] list){
        this.id = id;
        this.list = list;
    }
    
    /**
     * Gets the list of contiguous features.
     * @return Array of ints containing IDs of contiguous features.
     */    
    public int[] getList(){
        return list;
    }
    
    /**
     * Gets the ID of the feature which this ContiguityList represents.
     * @return The ID as an int.
     */    
    public int getID(){
        return id;
    }
        
}