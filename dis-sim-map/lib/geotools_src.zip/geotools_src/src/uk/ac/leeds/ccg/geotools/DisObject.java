package uk.ac.leeds.ccg.geotools;

public class DisObject {

	public int entityHashID;
	public boolean isSelected;
	public String entityMarking;
	public int entityForceID;
	public LatLonPoint entityLocation;
	public int timeToLive = 15; //15 seconds timeout
}
