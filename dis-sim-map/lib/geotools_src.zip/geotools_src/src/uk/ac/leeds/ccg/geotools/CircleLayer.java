/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;

import java.util.*;
import java.awt.*;

/**
 * A layer for containing a feature set of GeoCircles.
 * Circle Layer now extends ShapeLayer which now does a lot of the common work for layers.
 *
 * $Log: CircleLayer.java,v $
 * Revision 1.2  2002/01/06 21:22:04  jmacgill
 * Updated and fixed JavaDoc comments.
 *
 *
 * @version $Revision: 1.2 $ $Date: 2002/01/06 21:22:04 $
 * @author James Macgill
 * @since before 0.8.0
 */
public class CircleLayer extends ShapeLayer implements Layer, LockableSize {
    
    
    
    /**
     * Switches locked radius on and off.
     */
    protected boolean lockRadiusOn = false;
    
    
    /**
     * Locked radius size.
     */
    public int lockedRadius = 10;
    
    
    
    /**
     * Adds the specified GeoCircle to the GeoMap.
     *
     * @param circle the GeoCircle to be added.
     */
    public void addGeoCircle(GeoCircle circle) {
        super.addGeoShape(circle);
    }
    
    
    
    
    /**
     * Sets the lockRadius switch.
     *
     * @param flag true if lockRadius should be on.
     */
    public void setIsLockRadiusOn(boolean flag){
        lockRadiusOn = flag;
    }
    
    /**
     * Sets radius in pixels, to use if lock radius is enabled.
     *
     * @param size the size of the radius in pixels.
     */
    public void setLockedRadius(int size){
        lockedRadius = size;
    }
    
    /**
     * Paints a scaled version of the layer to the given graphics context.
     * <br>Generally only called by a theme that contains this layer.
     *
     * @param gg a GeoGraphics containing all of the info needed to paint this layer to screen.
     */
    public void paintScaled(GeoGraphics gg){
        Graphics g = gg.getGraphics();
        Scaler scale = gg.getScale();
        Shader shade = gg.getShade();
        GeoData data = gg.getData();
        ShadeStyle style = gg.getStyle();
        Filter filter = gg.getFilter();
        int p[],r;
        
        if(!style.isFilled()&&!style.isOutlined()) return;
        //System.out.println(shapeList.size());
        GeoCircle temp;
        r = lockedRadius;
        int id;
        for(int i = 0;i < shapeList.size() ;i++) {
            temp = (GeoCircle)shapeList.elementAt(i);
            
            p = scale.toGraphics(temp.getX(),temp.getY());
            if(!lockRadiusOn){
                r = scale.toGraphics(temp.getRadius());
            }
            
            //scaledPolygon = scale.scalePolygon(new GeoPolygon(temp));
            
            //Add thematic colour here
            id = temp.getID();
            if(filter==null || filter.isVisible(id)){
                double value = data.getValue(id);
                g.setColor(shade.getColor(value));
                if(style.isFilled()){
                    g.fillOval(p[0]-r,p[1]-r,2*r+1,2*r+1);
                }
                if(style.isOutlined()){
                    if(!style.isLineColorFromShader()){
                        g.setColor(style.getLineColor());
                    }
                    g.drawOval(p[0]-r,p[1]-r,2*r,2*r);
                }
            }
            
            
            
            
            //polys[i] = scaledPolygon.toAWTPolygon();
            temp = null;
        }
    }
    
    
    
    /**
     * Find the feature that contains this point.
     * <b>Note</b> This method will return the first feature found to contain the point only,
     * even if multiple, overlapping features, contain the same point.
     *
     * @param p the GeoPoint to test each feature against.
     * @param s the current scale, used to calculate distance in pixels from point.
     * @return the ID of the first feature to contain this point, -1 if no feature was found.
     */
    public int getID(GeoPoint p,Scaler s){
        if(!lockRadiusOn){
            return super.getID(p);
        }
        double r = s.toMap(lockedRadius);
        for(int i = 0;i < shapeList.size();i++) {
            GeoCircle temp = (GeoCircle)shapeList.elementAt(i);
            temp.setRadius(r);
            if(temp.contains(p)){
                return temp.getID();
            }
        }
        return -1;
    }
    
    /**
     * Highlights the specified feature.
     * A simple version of paintScaled, this is used to paint a single feature
     * in some way that makes it stand out from the other features.<br>
     * To date, this has been done by using a bright red colour.  A more user-definable
     * system may be implemented in later versions.<br>
     * Again, the only thing that should call this is a Theme.<br>
     *
     * @param g a Graphics object to paint the highlighted feature to.
     * @param scale a scaler that can be used to scale the feature.
     * @param id an int for the ID of the feature to be highlighted.
     * @param style a style with hints on how to display the highlight.
     * @see uk.ac.leeds.ccg.geotools.Theme
     */
    public void paintHighlight(Graphics g,Scaler scale,int id,ShadeStyle style){
        int p[],r;
        
        r = lockedRadius;
        for(int i = 0;i < shapeList.size();i++) {
            GeoCircle temp = (GeoCircle)shapeList.elementAt(i);
            if(temp.getID()==id){
                p = scale.toGraphics(temp.getX(),temp.getY());
                if(!lockRadiusOn){
                    r = scale.toGraphics(temp.getRadius());
                }
                //Add thematic colour here
                g.setColor(style.getFillColor());
                g.fillOval(p[0]-r,p[1]-r,2*r,2*r);
                g.drawOval(p[0]-r,p[1]-r,2*r,2*r);
                return;
            }
        }
    }
    
    
    
    
    /**
     * Returns the total number of circles held by the GeoMap.
     *
     * @return the total number of circles held by the GeoMap.
     * @deprecated use {@link uk.ac.leeds.ccg.geotools.ShapeLayer#countFeatures} from {@link uk.ac.leeds.ccg.geotools.ShapeLayer} instead.
     */
    public int countCircles() {
        return super.countFeatures();
    }
    
    
    
    /**
     * Returns all of the GeoCircles in this layer, in a vector.
     *
     * @return all of the GeoCircles in this layer.
     * @deprecated use {@link ShapeLayer#getGeoShapes} from {@link ShapeLayer} instead.
     */
    public Vector getGeoCircles(){
        return shapeList;
    }
}
