package uk.ac.leeds.ccg.geotools;

public interface ShaderChangedListener
{
        void shaderChanged(ShaderChangedEvent sce);
}