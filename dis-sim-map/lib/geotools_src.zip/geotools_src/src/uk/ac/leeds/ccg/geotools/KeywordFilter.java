/*
 * KeywordFilter.java
 *
 * Created on February 1, 2002, 12:18 PM
 */

package uk.ac.leeds.ccg.geotools;

/**
 *
 * @author  jamesm
 */
public class KeywordFilter extends uk.ac.leeds.ccg.geotools.SimpleFilter {
    String keyword;
    GeoData data;
    /** Creates a new instance of KeywordFilter */
    public KeywordFilter(GeoData textData) {
        data = textData;
    }
    
    public void setKeyword(String word){
        if(word.equals(keyword))return;
        keyword = word.toLowerCase();
        System.out.println("Notify listeners of keyword change");
        notifyFilterChangedListeners(ThemeChangedEvent.DATA);
    }

    public boolean isVisible(int id) {
        String text = data.getText(id).toLowerCase();
        if(keyword==null)return true;
        if(keyword.trim().length()==0)return true;
        if(text==null)return false;
        return(text.indexOf(keyword)!=-1);
    }
    
    public Object clone(){
        return new KeywordFilter(data);
    }
}
