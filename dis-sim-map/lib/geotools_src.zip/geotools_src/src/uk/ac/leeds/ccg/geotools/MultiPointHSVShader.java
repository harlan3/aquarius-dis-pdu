/*
 * MultiPointHSVShader.java
 *
 * Created on March 20, 2001, 12:46 PM
 */

package uk.ac.leeds.ccg.geotools;
import java.util.*;
import java.awt.Color;
/**
 *
 * @author  jamesm
 * @version 
 */
public class MultiPointHSVShader extends RampShader implements Shader{
    public static final String name = java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Multi_Point_HSV_Shader");
    Vector shaders = new Vector(2);
    
    double[] values;
    /** Creates new MultiPointHSVShader */
    public MultiPointHSVShader(Color[] colors,double[] values) {
        int rampCount = values.length-1;
        if(rampCount<1) throw new IllegalArgumentException("MPHS>You must specify at least two coulor/value pairs");
        //System.out.println("There are "+rampCount+" ramps to build");
        for(int i=0;i<rampCount;i++){
            shaders.addElement(new HSVShader(colors[i],colors[i+1], true));
            ((HSVShader)shaders.lastElement()).setRange(values[i], values[i+1]);
            //System.out.println("Added "+i);
            //System.out.println("From "+values[i]);
            //System.out.println("Color "+colors[i]);
            //System.out.println("To "+values[i+1]);
            //System.out.println("Color "+colors[i+1]);
        }
        this.values = values;
    }
    
    public String getName(){
        return name;
    }

    
    public Color getColor(double value){
        if(value < values[0] || value > values[values.length-1]) return missingColor;
        
        for(int i=1;i<values.length;i++){
            if(value<=values[i]){
                return ((HSVShader)shaders.elementAt(i-1)).getColor(value);
            }
        }
        //should never get this far...
        return missingColor;
    }
    
    public void setKeyStyle(int styleCode) {
    }
    
}
