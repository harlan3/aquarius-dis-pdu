package uk.ac.leeds.ccg.geotools;

import java.util.*; //change for 1.2!
import java.awt.*;
import uk.ac.leeds.ccg.geotools.misc.*;
import uk.ac.leeds.ccg.widgets.*;
import java.lang.Math.*;

public class ClassificationShader extends DiscreteShader {
    private Shader color;
    private int cat=0;//number of catagories
    private GeoData data;
    private Color start,end;
    private boolean shortest;
    private boolean showInCatCount = true;
    private int mode;
    private Classifier classifier;
    
    public static final int EQUAL_INTERVAL=0, DIFFERENCE=1, QUANTILE = 2,BREAKS = 3;
    
    public ClassificationShader(){
    }
    
    public ClassificationShader(GeoData d,int cat,int mode){
        this(d,cat,mode,Color.blue,Color.red,true);
    }
    
    public ClassificationShader(GeoData d , int cat, int mode, Color start, Color end){
        this(d,cat,mode,start,end,true);
    }
    
    public ClassificationShader(GeoData d,int cat,int mode,Color start, Color end,boolean shortest){
        data = d;
        conf = new Configure();
        this.mode=mode;
        setupCats(cat,mode,start,end,shortest);
    }
    public int getMode(){
        return mode;
    }
    
    public int getNumberOfCatagories(){
        return cat;
    }
    public void setNumberOfCatagories(int c){
        cat=c;
    }
    public void setGeoData(GeoData gd){
        data = gd;
        setupCats(cat,mode,start,end,shortest);
    }
    /**
     * Gets a descriptive name for this shader type
     */
    public String getName(){return java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Classification_Shader");}
    
     /**
     * Sets the range for this shader by checking the range of
     * the given data set.
     * this method also makes sure the GeoData's missing value code
     * and the shaders missing value code match.
     * @param d The GeoData to pull the range from
     */
    public void setRange(GeoData d){
        System.out.println("Replacing data "+data+" with new one "+d);
        data=d;//not sure if this is a good idea...
        double temp = d.getMissingValueCode();
        if(temp!=missingCode){
            d.setMissingValueCode(missingCode);
            setRange(d.getMin(),d.getMax());
            d.setMissingValueCode(temp);
        }
        else{
            setRange(d.getMin(),d.getMax());
        }
        setupCats(cat,mode,start,end,shortest);
        this.notifyShaderChangedListeners();
        getKey().updateKey();
         rangeData = d;
    }
    
    public synchronized void setupCats(int cat,int mode,Color start, Color end,boolean shortest){
	String catName;
	double thisDataValue,nextDataValue;
        int numberOfDifferentValues,counter;
        this.start=start;
        this.end=end;
        this.cat=cat;
        this.shortest=shortest;
        this.mode=mode;
        if(cat>1){
            color = new HSVShader(start,end,shortest);
            color.setRange(1,cat);
        }
        else{
            color = new MonoShader(start);
        }
        keys.removeAllElements();
        Bin value;
        //     ArrayList list = sort(data);
        switch(mode){
            
            case EQUAL_INTERVAL:
                classifier = (Classifier) new EqualInterval(data,cat);
                break;
                
            case DIFFERENCE:
                classifier = (Classifier) new Difference(data,cat);
                break;
                
            case QUANTILE:
                classifier = new Quantile(data,cat);
                break;
            case BREAKS:
                classifier = (Classifier) new NaturalBreaks(data,cat);
                break;
        }
        Iterator binList = classifier.getBins().iterator();
        int i=1;
        
        ClassifierStats stats = new ClassifierStats();
        int binCounts[] = stats.countForEachBin(classifier,data);
        String countString = "";
        while(binList.hasNext()){
            Bin bin = (Bin)binList.next();
            
            if(this.showInCatCount) countString = " ["+binCounts[i-1]+"]";
            RangeItem k = new RangeItem(bin,color.getColor(i),bin.toString()+ countString);
            keys.addElement(k);
            i++;
        }
        getKey().updateKey();
        notifyShaderChangedListeners();
    }
    
    
    
    class Configure extends SimpleShader.Configure{
        ColorPickLabel startLabel,endLabel;
        TextField catCount;
        Checkbox direct;
        Checkbox inCat;
        Choice modeList;
        public void update(){
            super.update();
            startLabel.setPickColor(start);
            endLabel.setPickColor(end);
            catCount.setText(""+cat);
            direct.setState(shortest);
            inCat.setState(showInCatCount);
            switch(mode){
                case ClassificationShader.EQUAL_INTERVAL:
                    modeList.select(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Equal_Interval"));
                    break;
                case ClassificationShader.DIFFERENCE:
                    modeList.select(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Difference"));
                    break;
                case ClassificationShader.QUANTILE:
                    modeList.select(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Quantile"));
                    break;
                case ClassificationShader.BREAKS:
                    
                    modeList.select(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Breaks"));
                    break;
            }
        }
        
        public void actionChanges(){
            super.actionChanges();
            start = startLabel.getPickColor();
            end = endLabel.getPickColor();
            try{
                int tcat = Integer.valueOf(catCount.getText()).intValue();
                cat = tcat;
                showInCatCount = inCat.getState();
            }
            catch(NumberFormatException nfe){System.err.println("Invalid value for new catagory count "+nfe);}
            
            switch(modeList.getSelectedIndex()){
                case 0:
                    mode = ClassificationShader.EQUAL_INTERVAL;
                    break;
                case 1:
                    mode = ClassificationShader.DIFFERENCE;
                    break;
                case 2:
                    mode = ClassificationShader.QUANTILE;
                    break;
                case 3:
                    mode = ClassificationShader.BREAKS;
                    break;
            }
            setupCats(cat,mode,start,end,direct.getState());
        }
        
        public void addItems(){
            super.addItems();
            System.out.println("Adding label");
            Label sc = new Label(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Start_Color"));
            add(sc);
            startLabel = new ColorPickLabel(Color.gray);
            add(startLabel);
            Label ec = new Label(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("End_Color"));
            add(ec);
            endLabel = new ColorPickLabel(Color.gray);
            add(endLabel);
            add(new Label(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Catagory_Count")));
            catCount = new TextField("?");
            add(catCount);
            direct = new Checkbox(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Direct"),true);
            add(direct);
            inCat = new Checkbox(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Show_Counts"),true);
            add(inCat);
            modeList = new Choice();
            modeList.add(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Equal_Interval"));
            modeList.add(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Difference"));
            modeList.add(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Quantile"));
            modeList.add(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Natural_Breaks"));
            add(new Label(java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Mode")));
            add(modeList);
            
        }
    }
    
    
    //{{DECLARE_CONTROLS
    //}}
}
