package uk.ac.leeds.ccg.widgets;

import java.beans.*;
import java.beans.SimpleBeanInfo;

public class LayerStatePanelBeanInfo extends java.beans.SimpleBeanInfo
{
	
	private final static Class beanClass = LayerStatePanel.class;
}