package uk.ac.leeds.ccg.geotools;

import java.awt.Color;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

public class DisLayer extends PointLayer {
	
	public Map<Integer, DisObject> disObjectHashMap = new ConcurrentHashMap<>();
	public boolean mouseZoomInProgress = false;
	public boolean mousePanInProgress = false;
	
	private Marker m = new TriangleMarker();
	private static DisLayer instance;
	
	// Force ID
	// 0 Other 
	// 1 Friendly 
	// 2 Opposing 
	// 3 Neutral 
	
	private DisLayer() {

	}
	
    public static DisLayer getInstance() {
    	
    	if(instance == null)
    		instance = new DisLayer();
    	
    	return instance;
    }
    
    public void requestRepaint() {
    	
		if (!mouseZoomInProgress && !mousePanInProgress)
			notifyLayerChangedListeners(uk.ac.leeds.ccg.geotools.Layer.PENDING);
    }

	public void paintScaled(GeoGraphics gg) {
		
        for (Map.Entry<Integer, DisObject> entry : disObjectHashMap.entrySet()) {
        	
            Integer key = entry.getKey();
            DisObject disObject = entry.getValue();

			GeoPoint geoPoint = new GeoPoint(disObject.entityLocation.longitude, disObject.entityLocation.latitude);
			Color markerColor = Color.WHITE;
			
			if (disObject.entityForceID == 1)
				markerColor = Color.BLUE;
			else if (disObject.entityForceID == 2)
				markerColor = Color.RED;
			else if (disObject.entityForceID == 3)
				markerColor = Color.GREEN;
			
			m.paintScaled(gg, geoPoint, 8, markerColor, disObject.isSelected);
		}
	}
}