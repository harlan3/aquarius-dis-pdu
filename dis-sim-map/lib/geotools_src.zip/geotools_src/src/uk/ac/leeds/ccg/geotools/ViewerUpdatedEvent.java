package uk.ac.leeds.ccg.geotools;

import java.util.*;

public class ViewerUpdatedEvent extends java.util.EventObject
{
	public ViewerUpdatedEvent(Object source)
	{
		super(source);
	}
}