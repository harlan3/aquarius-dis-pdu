/*
 * ChunkServer.java
 *
 * Created on August 7, 2001, 5:14 PM
 */

package uk.ac.leeds.ccg.geotools;

/**
 *
 * @author  jamesm
 * @version 
 */
public interface ChunkProvider {

}

