package uk.ac.leeds.ccg.geotools;

public class LatLonPoint {

	public double latitude = 0.0;
	public double longitude = 0.0;
	
	public LatLonPoint(double latitude, double longitude) {
		
		this.latitude = latitude;
		this.longitude = longitude;
	}
	
	public String toString() {
		return new String(latitude + " " + longitude);
	}
}
