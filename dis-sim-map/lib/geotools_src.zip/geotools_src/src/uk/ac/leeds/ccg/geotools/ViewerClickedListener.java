package uk.ac.leeds.ccg.geotools;

public interface ViewerClickedListener extends java.util.EventListener
{
    public void viewerClicked(ViewerClickedEvent e);
}