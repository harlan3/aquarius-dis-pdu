package uk.ac.leeds.ccg.geotools;

public interface ViewerClickListener
{
    public void viewerClickEvent(double x,double y);
}