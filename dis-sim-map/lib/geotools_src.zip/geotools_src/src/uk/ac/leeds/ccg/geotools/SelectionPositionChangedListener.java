package uk.ac.leeds.ccg.geotools;

public interface SelectionPositionChangedListener extends java.util.EventListener {
    void selectionPositionChanged(SelectionPositionChangedEvent spce);

}