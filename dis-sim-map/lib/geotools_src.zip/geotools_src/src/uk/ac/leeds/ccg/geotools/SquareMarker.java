package uk.ac.leeds.ccg.geotools;
import java.awt.*;

public class SquareMarker implements uk.ac.leeds.ccg.geotools.Marker
{
    public void paintScaled(GeoGraphics gg,GeoPoint p, int size, Color color, boolean isSelected) {
    	
        Scaler s = gg.getScale();
        ShadeStyle st = gg.getStyle();
        int mid[] = s.toGraphics(p);
        Graphics g = gg.getGraphics();
        int x[] = {mid[0]-size,mid[0]-size,mid[0]+size,mid[0]+size};
        int y[] = {mid[1]-size,mid[1]+size,mid[1]+size,mid[1]-size};
        g.setColor(st.getFillColor());
        g.fillPolygon(x,y,4);
        g.setColor(new Color(42, 48, 53));
        g.drawPolygon(x,y,4);
    }
    
    public void paintHighlight(Graphics g,GeoPoint p,int size,Scaler scale,ShadeStyle style) {
     
        int mid[] = scale.toGraphics(p);
        
        size+=2;
        int x[] = {mid[0]-size,mid[0]-size,mid[0]+size,mid[0]+size};
        int y[] = {mid[1]-size,mid[1]+size,mid[1]+size,mid[1]-size};
        g.setColor(style.getFillColor());
        g.fillPolygon(x,y,4);
        g.setColor(new Color(42, 48, 53));
        g.drawPolygon(x,y,4);
        
    }
    
}


