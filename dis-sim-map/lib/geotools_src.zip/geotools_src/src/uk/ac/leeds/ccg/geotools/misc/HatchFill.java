/*
 * HatchFill.java
 *
 * Created on November 20, 2001, 12:16 PM
 */

package uk.ac.leeds.ccg.geotools.misc;
import java.awt.*;
/**
 *
 * @author  jamesm
 * @version
 */
public class HatchFill {
    
    

        
        /** Creates new CrossHatch */
        public HatchFill() {
        }
        
        public static void hatchPolygon(Graphics g,Polygon poly,int angle,int distance){
            int x[] = poly.xpoints;
            int y[] = poly.ypoints;
            int n = poly.npoints;
            double slope;
            
            double px[] = new double[n];
            double py[] = new double[n];
            
            double c,s,p;//cos/sine of angle offset of tmp polygon
            int k;
            
            c= Math.cos(angle*Math.PI/180.0d);
            s= Math.sin(angle*Math.PI/180.0d);
            double HI =-Double.MAX_VALUE;
            double LO =Double.MAX_VALUE;
            
            //rotate the polygon so that hatch lines are horezontal
            for(int i=0;i<n;i++){
                px[i]=(x[i]*c+y[i]*s);
                p=-x[i]*s+y[i]*c;
                LO = Math.min(p,LO);
                HI = Math.max(p,HI);
                py[i] = p;
            }
            p = amod(py[0]-LO,distance)+LO;
            
            
            if(p>LO) p=p-distance;
            k = (int)((HI-p)/distance);
            if(k<=0 && distance<=0){
                //System.err.println("No hatching possible");
                return;
            }
            else {
                double[] ord = new double[k];
                //k is the number of hatches to draw
                for(int i=0;i<k;i++){
                    int m=0;
                    p+=distance;
                    for(int l=0;l<n;l++){
                        int j = (l+1)%n; // index of "next" point
                        if(py[l]<=p&&py[j]<=p) continue;
                        if(py[l]>p&&py[j]>p) continue;
                        ord[m]=px[l]+(px[j]-px[l])*(p-py[l])/(py[j]-py[l]);
                        m++;
                    }
                    if(m%2!=0){System.err.println("Rounding error in cross hatch");}
                    if(m==0)continue;
                    //sort ord
                    for(int j=1;j<m;j++){
                        int ns = m+1-j;
                        for(int l=1;l<ns;l++){
                            if(ord[l-1]>ord[l]){
                                double q = ord[l];
                                ord[l]=ord[l-1];
                                ord[l-1]=q;
                            }
                        }
                    }
                    int ns=0;
                    int xh[] = new int[n];
                    int yh[] = new int[n];
                    for(int j=1;j<m;j=j+2){
                        for(int jj=0;jj<2;jj++){
                            xh[jj]=(int)(ord[ns]*c-p*s);
                            yh[jj]=(int)(ord[ns]*s+p*c);
                            ns++;
                        }
                        g.drawLine(xh[0],yh[0],xh[1],yh[1]);
                    }
                }
            }
        }
        
        public static double amod(double a,double b){
            int first = (int)(a/b);
            double second = first*b;
            double third = a-second;
            return third;
        }
    }
