package uk.ac.leeds.ccg.geotools;

import java.util.List;
import java.awt.Color;
import java.awt.Font;
import java.awt.FontMetrics;
import java.awt.Graphics;
import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.ArrayList;

public class CountryLabels {

	// inner class
	private class CountryLabel {
		public String country;
		public double latitude;
		public double longitude;
		public int labelSize;
	}

	List<CountryLabel> labelList = new ArrayList<CountryLabel>();

	CountryLabels() {

		File file = new File("country_labels.csv");

		try {
			BufferedReader br = new BufferedReader(new FileReader(file));
			String line;
			int index = -1;
			while ((line = br.readLine()) != null) {

				index++;

				if ((index == 0) || line.startsWith("#"))
					continue;

				String[] values = line.split(",");

				CountryLabel countryLabel = new CountryLabel();
				countryLabel.country = values[1].replace("\"", "");
				countryLabel.latitude = Double.parseDouble(values[2]);
				countryLabel.longitude = Double.parseDouble(values[3]);
				countryLabel.labelSize = Integer.parseInt(values[4]);

				labelList.add(countryLabel);
			}
		} catch (Exception e) {
		}
	}
	
	private int getFontSize(int labelSize) {
		
		int retSize = 0;
		
		switch(labelSize) {
		
		case 1:
			retSize = 20;
			break;
			
		case 2:
			retSize = 16;
			break;
			
		case 3:
			retSize = 12;
			break;
			
		case 4:
			retSize = 8;
			break;
			
		case 5:
			retSize = 4;
			break;
			
		}
		
		return retSize;
	}
	
	private double[] project(double lon,double lat){
		
		double p[] = new double[2];
		int y_offset = -10;
		
		double mapWidth = 1904.0;
		double mapHeight = 960.0;
		
		double x = (lon+180.0)*(mapWidth/360.0);
		double y = (lat+90.0)*(mapHeight/180.0);
		
		p[0] = x;
		p[1] = mapHeight - y - y_offset;
		
		return p;
	}
	
    public void paintLabel(int index, String text, Graphics g, Scaler scale, GeoPoint p, int size) {
    	
        int mid[] = scale.toGraphics(p);
        int x = mid[0];
        int y = mid[1];
        FontMetrics fm = g.getFontMetrics(new Font("Arial", Font.PLAIN, getFontSize(size)));
        int width = fm.stringWidth(text) / 2;
        g.setFont(new Font("Arial", Font.BOLD, getFontSize(size)));
        //if (index == (labelList.size()-1))
        //	g.setColor(java.awt.Color.green);
        //else
        	g.setColor(new Color(211, 211, 211));
        g.drawString(text, (int) p.x - width, (int) p.y);
    }
    
	public void drawLabels(Graphics g, Scaler scale) {
		
		int index = 0;
		
		for (CountryLabel countryLabel : labelList) {
			
			double[] latlon = project(countryLabel.longitude, countryLabel.latitude);
			GeoPoint point = new GeoPoint(latlon[0], latlon[1]);
			paintLabel(index, countryLabel.country, g, scale, point, countryLabel.labelSize);
			
			index++;
		}
	}
}
