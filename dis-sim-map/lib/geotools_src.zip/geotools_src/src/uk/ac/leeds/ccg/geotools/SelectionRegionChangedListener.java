package uk.ac.leeds.ccg.geotools;

public interface SelectionRegionChangedListener extends java.util.EventListener {
    void selectionRegionChanged(SelectionRegionChangedEvent hpce);

}