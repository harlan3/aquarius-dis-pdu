/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;
import java.util.*;


/**
 * Fired when the number, state or visibility of the Themes within a Viewer changes. 
 * 
 * $Log: CompositionChangedEvent.java,v $
 * Revision 1.2  2002/02/23 23:07:39  loxnard
 * Fixed JavaDoc comments.
 *
 *
 * @author James Macgill 
 * @version $Revision: 1.2 $ $Date: 2002/02/23 23:07:39 $
 * @since before 0.8.0
 */
public class CompositionChangedEvent extends java.util.EventObject
{
    
    /**
     * Reason code: new Theme added.
     */
    public static final int ADDED = 1;
    
    /**
     * Reason code: Theme removed.
     */
    public static final int REMOVED = 2;
    
    /**
     * Reason code: Theme made visible/invisible.
     */
    public static final int VISIBILITY = 4;
    
    /**
     * Reason code: Themes reordered.
     */    
    public static final int ORDER=8;
	private int reason;
    
        /**
         * Constructs new event.
         * @param source The Viewer which has changed.
         * @param r The nature of the change.
         */        
    public CompositionChangedEvent(java.awt.Component source, int r){
        super(source);
        reason =r;
    }
    
    /**
     * Determines the reason for the event.
     * @return Reason code: one of added, removed, visibility or order.
     */    
    public int getReason(){
        return reason;
    }
}