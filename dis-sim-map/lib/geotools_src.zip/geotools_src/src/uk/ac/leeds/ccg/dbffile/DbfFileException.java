package uk.ac.leeds.ccg.dbffile;
/**
 * Thrown when an error relating to the shapefile
 * occures
 */
public class DbfFileException extends Exception{
    public DbfFileException(String s){
        super(s);
    }
}




