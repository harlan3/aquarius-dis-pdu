package uk.ac.leeds.ccg.widgets;

public interface ProgressEventListener extends java.util.EventListener {
		void progressChanged(ProgressChangedEvent tce);
}

