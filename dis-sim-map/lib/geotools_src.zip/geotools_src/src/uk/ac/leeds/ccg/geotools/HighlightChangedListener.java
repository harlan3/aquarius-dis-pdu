package uk.ac.leeds.ccg.geotools;

public interface HighlightChangedListener extends java.util.EventListener {
    void highlightChanged(HighlightChangedEvent hce);
    
}