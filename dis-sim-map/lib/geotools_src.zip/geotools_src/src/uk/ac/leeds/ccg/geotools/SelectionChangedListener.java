package uk.ac.leeds.ccg.geotools;

public interface SelectionChangedListener extends java.util.EventListener {
    void selectionChanged(SelectionChangedEvent hce);
  
}