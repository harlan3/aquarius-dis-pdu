package uk.ac.leeds.ccg.geotools;

/**
 * Encapsulates the geocentric coordinate system in meters. This is also know as
 * ECEF, (Earth Centered - Earth Fixed). ECEF uses three-dimensional XYZ
 * coordinates to describe the location of an entity. The the origin of the axis
 * (0,0,0) is located at the center of the mass of gravity of the Earth.
 *
 */
public class GeocentricPoint {

	// Define the WGS84 ellipsoid constants
	private static final double a = 6378137.0; // Semi-major axis (equatorial radius in meters)
	private static final double f = 1 / 298.257223563; // Flattening
	private static final double e2 = 2 * f - f * f; // Square of eccentricity
	private static final double b = a * (1 - f); // Semi-minor axis

	public double x;
	public double y;
	public double z;

	/**
	 * Construct a default GeocentricPoint. x,y,z are all set to zero.
	 */
	public GeocentricPoint() {
		x = 0.0d;
		y = 0.0d;
		z = 0.0d;
	}

	/**
	 * Construct a GeocentricPoint from x,y,z points.
	 *
	 * @param pX ecef x point in meters.
	 * @param pY ecef y point in meters.
	 * @param pZ ecef z point in meters.
	 */
	public GeocentricPoint(double pX, double pY, double pZ) {
		x = pX;
		y = pY;
		z = pZ;
	}

	/**
	 * Construct a GeocentricPoint from a LatLonPoint.
	 *
	 * @param llpt LatLonPoint.
	 */
	public GeocentricPoint(LatLonPoint llpt) {

		double latRad = Math.toRadians(llpt.latitude);
		double lonRad = Math.toRadians(llpt.longitude);
		double altitude = 0.0;

		double sinLat = Math.sin(latRad);
		double cosLat = Math.cos(latRad);
		double sinLon = Math.sin(lonRad);
		double cosLon = Math.cos(lonRad);

		// Radius of curvature in the prime vertical
		double N = a / Math.sqrt(1 - e2 * sinLat * sinLat);

		// Calculate X, Y, Z
		x = (N + altitude) * cosLat * cosLon;
		y = (N + altitude) * cosLat * sinLon;
		z = (N * (1 - e2) + altitude) * sinLat;
	}

	/**
	 * Convert a LatLonPoint from a GeocentricPoint.
	 *
	 */
	public LatLonPoint getLatLonPoint() {

		double e2Prime = (a * a) / (b * b) - 1; // Second eccentricity squared

		double p = Math.sqrt(x * x + y * y);
		double theta = Math.atan2(z * a, p * b);

		// Calculate latitude (phi)
		double sinTheta = Math.sin(theta);
		double cosTheta = Math.cos(theta);
		double latitude = Math.atan2(z + e2Prime * b * sinTheta * sinTheta * sinTheta,
				p - e2 * a * cosTheta * cosTheta * cosTheta);

		// Calculate longitude (lambda)
		double longitude = Math.atan2(y, x);

		// Calculate altitude (h)
		double N = a / Math.sqrt(1 - e2 * Math.sin(latitude) * Math.sin(latitude));
		double altitude = p / Math.cos(latitude) - N;

		LatLonPoint llpt = new LatLonPoint(Math.toDegrees(latitude), Math.toDegrees(longitude));
		return llpt;
	}
	
	public String toString() {
		
		return new String(x + " " + y + " " + z);
	}

	public final static void main(String[] args) {

		LatLonPoint llpt = new LatLonPoint(37.8106, -95.4369);
		System.out.println("llpt " + llpt.toString());
		GeocentricPoint gcc = new GeocentricPoint(llpt);
		System.out.println("gcc " + gcc.toString());
		LatLonPoint llpt2 = gcc.getLatLonPoint();
		System.out.println("llpt2 " + llpt2.toString());
	}

}
