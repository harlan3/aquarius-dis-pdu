/*
 * GeoTools java GIS tookit (c) The Centre for Computational Geography 2002
 *
 * This library is free software; you can redistribute it and/or modify it under the terms
 * of the GNU Lesser General Public License as published by the Free Software Foundation version 2.1
 */

package uk.ac.leeds.ccg.geotools;
import java.awt.Cursor;

/**
 * Provides the zoom functionality for viewers.
 * OneClickZoomInTool is a simple alternative to the zoom tool that zooms in on a point.
 *
 * $Log: CenterOnPointTool.java,v $
 * Revision 1.5  2002/02/26 22:06:02  jmacgill
 *
 * All printed strings have been replaced by a call to the i18n.properties bundle
 * This should make it very easy for anyone to translate geotools without recompiling any code.
 *
 * Revision 1.4  2002/01/06 20:35:32  jmacgill
 * Fixed and updated JavaDoc comments.
 *
 *
 * @author James Macgill
 * @version $Revision: 1.5 $ $Date: 2002/02/26 22:06:02 $
 * @since 0.7.9
 */
public class CenterOnPointTool extends SimpleTool{
   
   
    /**
     * Returns the default cursor type for this tool.
     * In this instance, a HAND_CURSOR.
     * 
     * @return Cursor the default cursor for this tool
     */
    public Cursor getCursor(){
        return  new Cursor(Cursor.HAND_CURSOR);
    }
    

    
    /**
     * Called when a mouse button has been clicked.
     * The view is centered on the point of the click.
     */
    public void click(){     
        
       
        context.centerOnPoint(mouse.getMapPoint());
        super.click();//clean up
    }
    /** Return one of the above constants to specify which rubberband should be automatically displayed during mouse drag events.
     *
     * @return the constant value NONE.
     */    
    public int getRubberBandShape(){
        return NONE;
    }
    
     /**
   * Provides a short name for this tool.
   * The name should be suitable for inclusion in a menu or on a button.
   *
   * @return the name of this tool.
   */
   public String getName(){
    return java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Center");
   }
   
   /**
   * Provides a description for this tool.
   * The description should briefly describe the purpose of the tool.
   *
   * @return a description of this tool.
   */
   public String getDescription(){
    return java.util.ResourceBundle.getBundle("uk/ac/leeds/ccg/geotools/i18n").getString("Centers_the_map_on_selected_point");
   }
}