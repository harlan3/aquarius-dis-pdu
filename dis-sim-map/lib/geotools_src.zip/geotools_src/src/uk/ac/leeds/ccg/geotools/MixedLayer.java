/*
 * MixedLayer.java
 *
 * Created on August 7, 2001, 2:59 PM
 */

package uk.ac.leeds.ccg.geotools;

/**
 *
 * @author  jamesm
 * @version
 */
public class MixedLayer extends uk.ac.leeds.ccg.geotools.MultiLayer implements uk.ac.leeds.ccg.geotools.Layer {
    protected boolean hasPolygons = false,hasLines = false, hasPoints = false;
    protected PolygonLayer polys;
    protected LineLayer lines;
    protected PointLayer points;
    
    /** Creates new MixedLayer */
    public MixedLayer() {
    }
    
    public MixedLayer(DataSource source){
    }
    
    public void addLayer(Layer l) {
        throw new IllegalArgumentException("Mixed Layer does not support the addition of extra layers, please use MultiLayer instead");
    }
    
    public void addGeoShape(GeoShape gs){
        if(gs instanceof GeoPolygon){
            addGeoPolygon((GeoPolygon)gs);
        }
        else if(gs instanceof GeoPoint){
            addGeoPoint((GeoPoint)gs);
        }
        else if(gs instanceof GeoLine){
            addGeoLine((GeoLine)gs);
        }
    }
        
    
    public void addGeoPolygon(GeoPolygon p){
        addGeoPolygon(p,getStatus()!=Layer.COMPLETED);
    }
    
    public void addGeoPoint(GeoPoint p){
        addGeoPoint(p,getStatus()!=Layer.COMPLETED);
    }
    
    public void addGeoLine(GeoLine l){
        addGeoLine(l,getStatus()!=Layer.COMPLETED);
    }
    
    
    
    public void addGeoPolygon(GeoPolygon p,boolean quiet) {
        if(!hasPolygons){
            polys = new PolygonLayer();
            super.addLayer(polys);
            hasPolygons = true;
        }
        polys.addGeoPolygon(p,quiet);
    }
    
    public void addGeoPoint(GeoPoint p,boolean quiet) {
        if(!hasPoints){
            points = new MarkerLayer();
            super.addLayer(points);
            hasPoints = true;
        }
        points.addGeoPoint(p,quiet);
    }
    
    public void addGeoLine(GeoLine l,boolean quiet) {
        if(!hasLines){
            lines = new LineLayer();
            super.addLayer(lines);
            hasLines = true;
        }
        lines.addGeoLine(l,quiet);
    }
    
    public PolygonLayer getPolygonLayer(){
        return this.polys;
    }
    
    public LineLayer getLineLayer(){
        return this.lines;
    }
    
    public PointLayer getPointLayer(){
        return this.points;
    }
    
    /** Getter for property hasLines.
     * @return Value of property hasLines.
     */
    public boolean isHasLines() {
        return hasLines;
    }    
    
    /** Getter for property hasPoints.
     * @return Value of property hasPoints.
     */
    public boolean isHasPoints() {
        return hasPoints;
    }
    
    /** Getter for property hasPolygons.
     * @return Value of property hasPolygons.
     */
    public boolean isHasPolygons() {
        return hasPolygons;
    }
    
}
